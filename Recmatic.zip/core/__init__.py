# Makes core a package
